<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>

<p><?php esc_html_e( 'Choose your request api version', 'acf-to-rest-api' ); ?></p>
